using System;
using System.Collections.Generic;

public class Solution
{
    public bool ContainsDuplicate(int[] nums)
  {
        HashSet<int> set = new HashSet<int>();
        foreach (int num in nums) 
        {
            if (set.Contains(num)) 
            {
                return true;
            }
            set.Add(num);
        }
        return false;
    }
}

public class Program 
{
    public static void Main(string[] args)
  {
        int[] nums1 = {1, 2, 3, 4};
        int[] nums2 = {1, 1, 1, 3, 3, 4, 3, 2, 4, 2};
        int[] nums3 = {1, 2, 3, 1};

        Solution solution = new Solution();

        Console.WriteLine(solution.ContainsDuplicate(nums1)); 
        Console.WriteLine(solution.ContainsDuplicate(nums2)); 
        Console.WriteLine(solution.ContainsDuplicate(nums3)); 
    }
}